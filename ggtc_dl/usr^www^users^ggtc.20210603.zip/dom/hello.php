<?php

  print("<center>" );
  print("<b>Enumeration of data </b>" );
  print("<br>");


 for( $i = 0; $i <= 5; $i++){

      print($i." )     counting");

      print("<br>");

  }

  print("</center>" );

?>