<?php

  $theURL = "http://www.sfmongoldata.appspot.com/current";

  $theURL  = "http://www.sctennisclub.org/ggtc_/current";

  echo $theURL;



?>