function hello()
{

    document.write("<br>from library.js<br>")

}

function printf(mssg)
{

   document.writeln(printf.arguments[i]);

  /*	var i;
	var theLen = printf.arguments.length;

	for( i = 0 ; i< theLen ; i++)
		top.frames[1].document.writeln(printf.arguments[i]);

		top.frames[1].document.writeln('<br>');
 */

}

function flashpoint()
{

	printf('# (c) 1998 FlashPoint Technology, Inc. Digita and the Digita Logo are ');
	printf('# trademarks of FlashPoint Technology, Inc. ');

	printf('# This script may be reused in whole or in part as long as the modified ');
	printf('# script includes the following notice:  ');
	printf('# "Portions of this script are copyrighted by FlashPoint Technology Inc." ');
	printf(' ');

}

