<?php


  $theURL  = "http://www.sctennisclub.org/ggtc_/current";
  $theURL = "http://www.sfmongoldata.appspot.com/current";


  echo $theURL;



?>