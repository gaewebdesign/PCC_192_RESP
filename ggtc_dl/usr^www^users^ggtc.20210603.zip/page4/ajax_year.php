<?php

session_start();

$_SESSION["GYEAR"] = $_POST["GYEAR"] ; //2019;

return "ajaxed";

?>