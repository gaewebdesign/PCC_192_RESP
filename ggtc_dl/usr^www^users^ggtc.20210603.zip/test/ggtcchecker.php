<html>
<div align="center">
<h1>USTA / Golden Gate Tennis Club </h1>
</div>

<TABLE align="center" class="sortable" BORDER=1 cellpadding=0 cols=8 cellspacing=0  width="500"  bgcolor="linen">
<TR bgcolor="99ccff">
<TH width="150"><font size="2" >First Name</font></TH>
<TH width="150"><font size="2" >Last Name</font></TH>
<TH width="100"> <font size="2">City </font></TH>
<TH width="100"> <font size="2">Status </font></TH>
</tr>


<?php


define("COLORBLUE" , "DCEAFC");
define("COLORHEADER","99ccff");
define("COLORMEMBER","a9a9f5");
define("COLORWHITE" , "FFFFFF");

global $GAEMEMBERS;

$GAEMEMBERS = array();
$MEMBERS = array();

if( $_GET["year"] == 2018){

  define("YEAR_FOR_USTA", 2018);

}else{
   define("YEAR_FOR_USTA", 2019);


}


define("URLGAE", "http://www.sfmongoldata.appspot.com/ggtc");
//define("URLGAE", "http://localhost:8080/ggtc");
//define("URLGAE", "http://www.jeung4tennis.appspot.com/ggtc");

define("DOIT","0");
define("SKIP","1");
define("FINISH","2");


date_default_timezone_set('America/Los_Angeles');


global $MEMBERS;
$MEMBERS = array();

   echo "<center><b>".date("F d, Y ", time())."</b></center><br>" ;
   echo "<h1><center>".YEAR_FOR_USTA."</center></h1>";

// One time - get members and store in global array
   GetMembers();

   GetTeams( );

?>

</table>
<html>


<?php

function DEBUG($t)
{

//      echo( $t );

}

function ListMembers()
{
   global $MEMBERS;

   foreach( $MEMBERS as $key => $val){
        echo $key." ".$val." ";

   }
}



// Get players from DB and store into global array 
function GetMembers()
{

global $MEMBERS;
global $KOTOSHI;

//global $GAEMEMBERS;


$data = array( 'year' => YEAR_FOR_USTA );

//echo("SF url is ".URLGAE);

$payload = json_encode( $data );

$ch = curl_init(URLGAE);
curl_setopt( $ch  , CURLOPT_POSTFIELDS, $payload );
curl_setopt( $ch  , CURLOPT_RETURNTRANSFER, true );

$response = curl_exec($ch);
curl_close($ch);

$obj = json_decode($response, $assoc= TRUE);

//print("DATA <br>");
//print_r($obj);
//print("DATA <br>");

// convert from JSON

$u=1;
foreach( $obj as $row){

       // need  unique first name (append u) for hash table
       // trim white spaces and add $u (counter) to make first name unique

       $fname = trim($row['fname']).$u;
       $lname = trim($row['lname']);
       $MEMBERS[$fname] = $lname;
//     print("$u: storing $fname  $lname <br>");
       $u++;

} 


}



// Search on LNAME, then check for FNAME
function findMember($fname,$lname)
{
   global $MEMBERS;
   $search = 0;

   $retval=0;


   $fname =  trim($fname);
   $lname = trim($lname);


// HARD CODED for Jackie Davidson-Fenton
   if( strpos($fname,"Jackie") !== false && (strpos($lname,"Davidson")!==false)   )       $lname="Fenton";
   if( strpos($fname,"Carlos") !== false && (strpos($lname,"guzman") !==false)   )        $lname="Nino de Guzman";


//  preg_match("/Chiang/",$lname )

    if(preg_match("/Chiang/i",$lname ) ||  preg_match("/Isaacson/i",$lname )  ||  preg_match("/Hahn/i",$lname )||  preg_match("/Nettle/i",$lname )){

        DEBUG(" findMember(".$fname.", ".$lname.")<br>");
        $search =1;
   }

   $search=1;    

   $pattern=  "/".$lname."/i";
   $pattern=  "/^".$lname."/i";


   $found = preg_grep( $pattern , $MEMBERS) ;

   if(empty($found)){
              $retval=0;       // Didn't find last name
              DEBUG( "didnt find ".$lname);

   }else{
              if($search){

                DEBUG( "found ".$lname." now looking for ".$fname."<br>");
              }

              // Look for first name (first 3 characters)
              $pattern = "/".rtrim(substr($fname,0,2))."/i";


              foreach ($found as $first => $last){

                   if($search){
                     DEBUG( "now looking for ".$pattern." in ".$first."<br>");
                   }


                  if( preg_match( $pattern, $first,$matches)) {
                            $retval= 1;
                            if($search){
                             DEBUG( "found ".$pattern." in ".$first."<-------------<br>");
                             DEBUG( "return ".$retval."<br>");
                             return $retval;
                             }                     

                  }
              }
   }   
   



   return $retval;


}

function Table( )
{
  echo '<TABLE align="center" class="sortable" BORDER=1 cellpadding=0 cols=8 cellspacing=0  width="500"  bgcolor="linen">';
}

function EndTable( )
{
  echo '</table><br>';
}

function GetTeams( )
{

// http://www.oooff.com/php-scripts/basic-php-scrape-tutorial/basic-php-scraping.php

$url = 'https://ustanorcal.com/organization.asp?id=3483';   // Santa Clara at Central Park

$url = 'https://ustanorcal.com/organization.asp?id=1787';   // GGPark

$url = 'https://ustanorcal.com/organization.asp?id=1787';   // GGPark

if( YEAR_FOR_USTA == 2018){

$url = 'https://ustanorcal.com/organization.asp?id=1787&archive=Y';   // GGPark

}


//$output = file_get_contents($url);
//echo $output;
//echo "parsing";

$ch = curl_init($url);


// http://www.oooff.com/php-scripts/basic-curl-scraping-php/basic-scraping-with-curl.php
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$curl_scraped_page = curl_exec($ch);
curl_close($ch);



// Get Santa Clara TennisClub 
// changed (Santa Clara [^<])< to ([^<])<  (get everything except <)
preg_match_all( '/href=teaminfo.asp\?id=([\d]*)>([^<]*)<[ .\w\d\/<>=#]*?align=left>([-\w]*)[ ,]*([-\w]*)/i', $curl_scraped_page , $_teaminfo , PREG_PATTERN_ORDER);

// Pull in ID, Team Name </td> <td Area </td><td Captain</td>
$regexp = '/href=teaminfo.asp\?id=([\d]*)>([^~]*?)<\/a><\/td>';  // ID, Team Name
$regexp .= '<td [^~]*?<\/td>';      // Area (not used)
$regexp .= '<td ([^~]*?)<\/td>';    // Captain 
$regexp .= '/i';

preg_match_all( $regexp, $curl_scraped_page , $_teaminfo , PREG_PATTERN_ORDER);

//print_r($_teaminfo);


$regCaptain = '/align=left>([^,]*?)[ ,]*([^,]*?)$/i';
for($j=0 ; $j < count($_teaminfo[0]) ; $j++){

        $teamid   =  $_teaminfo[1][$j];
        $teamlink =  $_teaminfo[2][$j];

// Extract the Captain from this column
        preg_match_all( $regCaptain, $_teaminfo[3][$j] , $_captain, PREG_PATTERN_ORDER );
        $lname = $_captain[1][0];
        $fname = $_captain[2][0];
        $captain = $fname." ".$lname;

        $teamlink = '<a style=text-decoration:none href="https://ustanorcal.com/teaminfo.asp?id='.$teamid.'">'.$teamlink."</a>";


//      Cut off parsing
        $find=SKIP;

        if( YEAR_FOR_USTA == 2018){

           if( $teamid >= 81984) $find=SKIP;  // Before 2018

//         Team getting subsidy    
           if( $teamid == 80794 ) $find=GO;  // M7.0 Iegan McMahon

           if( $teamid == 80257 ) $find=GO;  // 55W8.0 Indorf

           if( $teamid == 78429 ) $find=GO;  // 40W4.0b Janet Broude 
           if( $teamid == 77675) $find=GO;  // 40W3.5 Pam Miller (Janet Broude)
           if( $teamid == 77848) $find=GO;  // 40W4.0a Tuck Wong

           if( $teamid == 78554) $find=GO;  // S Spies
           if( $teamid == 77593) $find=GO;  // 40W3.0 C Tejada
           if( $teamid == 78934) $find=GO;  // 40W3.5 C Tejada

           if( $teamid == 78843) $find=GO;  // 65W7.0A  M.Lennihan

// Adult season
           if( $teamid == 79424) $find=GO;  // M4.0  Kringstein
           if( $teamid == 79337) $find=GO;  // M4.0  Korenman
           if( $teamid == 79890) $find=GO;  // M3.5  Spires

        }

        if( YEAR_FOR_USTA == 2019){

           echo ".";
           if( $teamid == 82325) $find=FINISH;   // GGP TLM4.5A
           if( $teamid == 82052) $find=FINISH;   // GGP TLM4.5A
           if( $teamid == 82012) $find=FINISH;   // GGP 40M7.0a Mirian DeQuadros


        }

        if( $find == 0 ){
		Table( );

		TripleCell( COLORBLUE ,  $teamlink." <br>Captain ".$captain." " );
		echo "<tr>";
		GetTeamPlayers( 'https://ustanorcal.com/teaminfo.asp?id='.$teamid );
		EndTable( );
		echo "<tr>";

	}elseif( $find == SKIP){

        }elseif( $find == FINISH ){
		break;

	}

        $count ++;
        $find=0;



}


}



function GetTeamPlayers( $url )
{


global $USTA_RESIDENT, $USTA_NONRESIDENT;


// echo "get playaers from ".$url;


 $ch = curl_init($url);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 $curl_scraped_page = curl_exec($ch);
 curl_close($ch);

# Original matcher
//preg_match_all( '/href=playermatches.asp\?id=([\d]*)>([ -\w]*)[ ,]*([ -\w]*)[ <>\w=#\d\/]*?nowrap>([ \w]*)/', $curl_scraped_page , $_players , PREG_PATTERN_ORDER);


/*
<a href=playermatches.asp?id=114612>Adams, Jennifer A </a></td>
<td bgcolor=white align=left nowrap>San Jose</td>
<td bgcolor=white align=center>F</td>
<td align=center bgcolor=white>4.5C</td>
<td align=center bgcolor=white></td>
<td align=center bgcolor=white>3/31/2016</td>
<td bgcolor=white align=center>2 / 1</td
*/

  $pattern = "/href=playermatches.asp\?id=([\d]*)>";     // ID

  $pattern .= "([ ,\'\-\w]*)<\/a><\/td>";  //  name

  $pattern .= "<td bgcolor=[#\d\w]* align=left nowrap>([ \w\d]*)<\/td>";   // city

  $pattern .= "<td bgcolor=[#\d\w]* align=center>([MF]{1})<\/td>";   // gender

  $pattern .= "<td align=center bgcolor=[#\d\w]*>([\d\w\.]*)<\/td>";   // rating

  $pattern .= "<td align=center bgcolor=[#\d\w]*>([\w]*)<\/td>";   // national

  $pattern .= "<td align=center bgcolor=[#\d\w]*>([\d\/]*)<\/td>";   // expire

//  $pattern .= "<td bgcolor=[#\d\w]* align=center>([ \d\/\(\)\>\<b]*)<\/td>";   // record

   $pattern .= "<td bgcolor=[#\d\w]* align=center>([ \d\/]*)([\d\w\<\>\/]*)<\/td>";   // record


  $pattern .= "/";

  preg_match_all($pattern , $curl_scraped_page, $_player,PREG_PATTERN_ORDER);
  $players = count( $_player[0] );

  for ( $j = 0 ; $j < $players ; $j++){
            $id = $_player[1][$j];
            $name = $_player[2][$j];
            $city = $_player[3][$j];
            $gender = $_player[4][$j];
            $rating = $_player[5][$j];
            $nat = $_player[6][$j];
            $expire = $_player[7][$j];

            $record = $_player[8][$j];

            $record = str_replace(' ', '', $record);
            $record = str_replace('/', ' / ', $record);

   	    $bgColor =  COLORWHITE;

            
//    SPLIT INTO FIRST AND LAST NAMES
            $s = explode(',',trim($name),2);
            $lname = trim($s[0]);
            $fname = trim($s[1]);

            $l=$lname;
            $f = $fname;
            DEBUG( "TEAM ".$fname." ".$lname."<br>");
            $found = findMember($fname,$lname);
  	    if($found != 0) $bgColor =  COLORMEMBER;

            MCell($bgColor , trim($fname));
            MCell($bgColor , trim($lname));

//            MCell($bgColor , trim($f));
//            MCell($bgColor , trim($l));

            MCell($bgColor , $city);
            MCell($bgColor , "&nbsp;".$record."&nbsp;");

           echo "</tr>\r\n";

  }




}


function Center( $color , $data )
{
  
	echo "<td valign='middle' height=15 ALIGN=CENTER bgcolor=".$color." ><font size='3'>".$data."&nbsp</td>";

}


function MCell( $color , $data )
{
  
	echo "<td valign='middle' height=15 ALIGN=LEFT bgcolor=".$color." ><font size='3'>".$data."&nbsp</td>";

}


function TripleCell( $color , $data )
{
  
	echo "<td valign='middle' height=15 colspan=4 ALIGN=LEFT bgcolor=".$color." ><font size='3'>".$data."&nbsp</td>";

}




?>
